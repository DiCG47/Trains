/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainclient;

import javax.swing.JOptionPane;

/**
 *
 * @author Adrian Vinicio
 */
public class Main {
    public Cliente cliente = new Cliente();
    
    public static void main(String args[]){
        jfrmClientMenu gui = new jfrmClientMenu();
        gui.setVisible(true);

    }
}
