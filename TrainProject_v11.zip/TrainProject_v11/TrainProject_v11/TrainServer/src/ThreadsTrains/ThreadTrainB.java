/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ThreadsTrains;

import Routes.TrainsRoute;
import TrainServerTCP.ServerClient;
import static java.lang.Thread.sleep;
import java.util.logging.Level;
import java.util.logging.Logger;
import Routes.TrainPrice;

/**
 *
 * @author sramirez
 */
public class ThreadTrainB extends Thread {

    public TrainsRoute route;
    public ClassTrainB train;
    public TrainPrice price;
    boolean flag = true;

    public ThreadTrainB() {
        this.route = new TrainsRoute();
        this.train = new ClassTrainB();
    }

    @Override
    public void run() {
        
        train.setPasajeros((int) (Math.random() * (100 - 10 + 1) + 10)); //Se añaden pasajeros con un ramdom
        train.setMoneyB(train.getPasajeros() * price.tarifa.getPRECIO()); //Guarda la ganancia que va teniendo el tren
        System.out.println("El tren DOS ha ganado " + train.getMoneyB()); 
        train.setMoney(train.getMoneyB());
        System.out.println("Ganancias totales hasta el momento " + train.getMoney());//Ganancias generales de todos los trenes

        for (int i = 0; i < route.SizePlacesA().size() -1; i++) {
     
            
            if (train.getSuspenderB() != false) { //Valida si el hilo está suspendido con una variable booleana
                
                if (i == route.SizePlacesA().size()) { //El tren comienza de nuevo la ruta apenas la termina.
                    i = 0;
                }
                
                if (flag == false) { 
                    System.out.println(">>>>>>>>>>>Un administrador reanudó el servicio del tren DOS<<<<<<<<<<<<");
                }
                flag = true;

                train.setRecorrido(train.getRecorrido() + 1); //Acumula la cantidad de estaciones que ha visitado el tren
                System.out.println("El tren DOS está en la estación de " + route.getPlacesA(i) + " con " + train.getPasajeros() + " pasajeros.");
                train.setDestino(route.getPlacesA(i + 1)); 
                System.out.println("El tren DOS se dirige a la estacion de " + train.getDestino());
                train.setTiempoEspera(40);
                System.out.println("Tiempo en llegar del tren DOS a " + train.getDestino() + ": " + train.getTiempoEspera() + " minutos");

                for (int x = 0; x < 10; x++) {
                    try {
                        train.setTiempoEspera(train.getTiempoEspera() - 4); //Se va disminuyendo el tiempo que dura el tren de una esatcion al destino
                        sleep(2000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

                train.setTiempoEspera(10);

                System.out.println("El tren DOS ha llegado a la estacion " + train.getDestino() + " y va a salir en " + train.getTiempoEspera() + " minutos");

                for (int x = 0; x < 5; x++) {
                    try {
                        sleep(2000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                
                //Al llegar a la estación de destino suben y bajan pasajeros
                train.setPasajerosBajan((int) (Math.random() * (40 - 10 + 1) + 10));
                train.setPasajerosNuevos((int) (Math.random() * (50 - 10 + 1) + 10));

                if ((train.getPasajeros() + train.getPasajerosNuevos()) - train.getPasajerosBajan() <= 0) {
                    train.setPasajeros(0);
                } else {
                    train.setPasajeros((train.getPasajeros() + train.getPasajerosNuevos()) - train.getPasajerosBajan());
                }
                
                if (train.getPasajeros() > 150) {
                    while (train.getPasajeros() > 150) {
                        train.setPasajeros(train.getPasajeros() - 1);
                        train.setAcumulado(train.getAcumulado() + 1);
                    }
                }
                //Contabilización de las ganancias por tren y general
                train.setMoneyB(train.getMoneyB() + (train.getPasajerosNuevos() - train.getAcumulado()) * 500);
                System.out.println("El tren DOS ha ganado " + train.getMoneyB());
                train.setMoney((train.getPasajerosNuevos() - train.getAcumulado()) * 500);
                System.out.println("Ganancias totales hasta el momento " + train.getMoney());
            } else {
                if (flag) {
                    System.out.println(">>>>>>>>>>>Un administrador detuvo el servicio del tren DOS<<<<<<<<<<<<<");
                    flag = false;
                }
                System.out.print("");
                i--;
            }

        }//Fin del FOR
    }
}
