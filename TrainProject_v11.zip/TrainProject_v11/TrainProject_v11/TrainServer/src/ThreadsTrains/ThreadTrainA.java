/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ThreadsTrains;

import TrainServerTCP.ServerClient;
import Routes.TrainsRoute;
import static java.lang.Thread.sleep;
import java.util.logging.Level;
import java.util.logging.Logger;
import Routes.TrainPrice;

/**
 *
 * @author sramirez
 */
public class ThreadTrainA extends Thread {

    public TrainsRoute route;
    public ClassTrainA train;
    public TrainPrice price;
    boolean flag = true;

    public ThreadTrainA() {
        this.route = new TrainsRoute();
        this.train = new ClassTrainA();
    }

    @Override
    public void run() {

        train.setPasajeros((int) (Math.random() * (100 - 10 + 1) + 10));

        train.setMoneyA(train.getPasajeros() * price.tarifa.getPRECIO());
        System.out.println("El tren UNO ha ganado " + train.getMoneyA());
        train.setMoney(train.getMoneyA());
        System.out.println("Ganancias totales hasta el momento " + train.getMoney());

        for (int i = 0; i < route.SizePlacesA().size() - 1; i++) {
            
            if (train.getSuspenderA() != false) { //Valida el valor booleano para saber si el tren está suspendido
                
                if (i == route.SizePlacesA().size()) { //El tren comienza de nuevo la ruta apenas la termina.
                    i = 0;
                }

                if (flag == false) {
                    System.out.println(">>>>>>>>>>>Un administrador reanudó el servicio del tren UNO<<<<<<<<<<<<");
                }
                flag = true;

                train.setRecorrido(train.getRecorrido() + 1);

                System.out.println("El tren UNO está en la estación de " + route.getPlacesA(i) + " con " + train.getPasajeros() + " pasajeros.");
                train.setDestino(route.getPlacesA(i + 1));
                System.out.println("El tren UNO se dirige a la estacion de " + train.getDestino());
                train.setTiempoEspera(40);
                System.out.println("Tiempo en llegar del tren UNO a " + train.getDestino() + ": " + train.getTiempoEspera() + " minutos");

                for (int x = 0; x < 10; x++) {
                    try {
                        train.setTiempoEspera(train.getTiempoEspera() - 4); //Disminuye el tiempo de translado del tren
                        sleep(2000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

                train.setTiempoEspera(10);

                System.out.println("El tren UNO ha llegado a la estacion " + train.getDestino() + " y va a salir en " + train.getTiempoEspera() + " minutos");

                for (int x = 0; x < 5; x++) {
                    try {
                        sleep(2000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                //Al llegar a la estación de destino suben y bajan pasajeros
                train.setPasajerosBajan((int) (Math.random() * (40 - 10 + 1) + 10));
                train.setPasajerosNuevos((int) (Math.random() * (50 - 10 + 1) + 10));

                if ((train.getPasajeros() + train.getPasajerosNuevos()) - train.getPasajerosBajan() <= 0) {
                    train.setPasajeros(0);
                } else {
                    train.setPasajeros((train.getPasajeros() + train.getPasajerosNuevos()) - train.getPasajerosBajan());
                }

                if (train.getPasajeros() > 150) {
                    while (train.getPasajeros() > 150) {
                        train.setPasajeros(train.getPasajeros() - 1);
                        train.setAcumulado(train.getAcumulado() + 1);
                    }
                }
                //Contabilización de las ganancias por tren y general
                train.setMoneyA(train.getMoneyA() + (train.getPasajerosNuevos() - train.getAcumulado()) * 500);
                System.out.println("El tren UNO ha ganado " + train.getMoneyA());
                train.setMoney((train.getPasajerosNuevos() - train.getAcumulado()) * 500);
                System.out.println("Ganancias totales hasta el momento " + train.getMoney());
            } else {
                if (flag) {
                    System.out.println(">>>>>>>>>>>Un administrador detuvo el servicio del tren UNO<<<<<<<<<<<<<");
                    flag = false;
                }
                
                System.out.print("");
                i--;
            }
        } //Fin del FOR
    }
}
