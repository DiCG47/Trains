package Routes;

import java.util.ArrayList;
import TrainServerTCP.Base;

public class TrainsRoute extends Base {

    private ArrayList<String> Places = new ArrayList<String>(); //Lista de rutas que haras los trenes
    private static boolean a = true;

    public TrainsRoute(int id, String name, int maxcapacity, int routeid, int money, int moneyA) {
        super(id, name, maxcapacity, routeid, money);
    }

    public TrainsRoute() { //Se añaden los lugares
        Places.add("San Jose");
        Places.add("Guadalupe");
        Places.add("San Pedro");
        Places.add("Heredia");
        Places.add("La Isla");
        Places.add("Coronado");
    }

    public synchronized String getPlacesA(int x) {  ////Esto esta sincronizado 
        return Places.get(x);
    }

    public ArrayList<String> SizePlacesA() {
        return Places;
    }

    public void setPlacesA(ArrayList<String> PlacesA) {
        this.Places = PlacesA;
    }
}
