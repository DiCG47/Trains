/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Routes;

/**
 *
 * @author DiCG47 PC
 */
public enum TrainPrice {

    tarifa(500);

    private final int price;

    private TrainPrice(final int p) {
        this.price = p;
    }

    public int getPRECIO() { 
        return price; //Devuelve el precio de la tarifa
    }

}
