/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TrainServerTCP;

import Routes.TrainsRoute;
import ThreadsTrains.TrainBase;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Adrian Vinicio
 */
public class ServerClient implements Runnable {

    private Socket socket;
    private ObjectInputStream in;
    private ObjectOutputStream out;

    TrainBase trainA, trainB; 

    public ServerClient(final Socket socket, TrainBase trainA, TrainBase trainB) {
        //Cada uno de estas variables corresponde al hilo que fue iniciado en el main.
        this.trainA = trainA;
        this.trainB = trainB;

        this.socket = socket;
        startStream();
    }

    @Override
    public void run() {
        firstReadData();
    }

    public void startStream() {
        try {
            in = new ObjectInputStream(socket.getInputStream());
            out = new ObjectOutputStream(socket.getOutputStream());
        } catch (IOException ex) {
            System.out.print("");
            //Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void firstReadData() {
        try { //Se valida el tren del cuál va a consultar y quién está consultando
            String trenuser = in.readUTF(); 
            if (trenuser.contains("1")) { // ------- TRAIN A
                if (trenuser.contains("client")) {
                    readDataClient(trainA);
                } else if (trenuser.contains("admin")) {
                    readDataAdmin(trainA);
                }
            } else if (trenuser.contains("2")) { //------ TRAIN B
                if (trenuser.contains("client")) {
                    readDataClient(trainB);
                } else if (trenuser.contains("admin")) {
                    readDataAdmin(trainB);
                }
            }
        } catch (IOException ex) {
            System.out.print("");
            //Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void readDataClient(TrainBase train) {
        try {
            String mensaje = in.readUTF(); //Se lee la palabra clave que los clientes enviaron para hacer la petición de información

            switch (mensaje) { //Según la palabra recibida así responderá el servidor
                case "costo":
                    sendData("El costo del pasaje es 500 colones.");
                    break;
                case "tiempo":
                    if (train.getTiempoEspera() == 0) {
                        sendData("El tren se encuentra en la estacion de " + train.getDestino() +" saldra dentro de 10 minutos.");
                    } else {
                        sendData("El tiempo aproximado para que el tren llegue a la estacion " + train.getDestino() +" es de " + train.getTiempoEspera() + " minutos");
                    }
                    break;
                case "destino":
                    sendData("El destino del tren es la estacion " + train.getDestino());
                    break;
                default:
                    break;
            }
            readDataClient(train);
        } catch (IOException ex) {
            System.out.print("");
            //Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void readDataAdmin(TrainBase train) { //Trabaja de la misma forma que el cliente pero contiene más opciones
        try {
            String mensaje = in.readUTF();
       
            switch (mensaje) {
                case "destino":
                    sendData("El destino del tren es la estacion " + train.getDestino());
                    break;
                case "tiempo":
                    if (train == trainA) {
                        if (train.getTiempoEspera() == 0) {
                            sendData("El tren UNO se encuentra en una estacion, saldra dentro de 10 minutos");
                        } else {
                            sendData("El tiempo aproximado para que el tren UNO llegue a la estacion de " + train.getDestino() + " es de " + train.getTiempoEspera() + " minutos");
                        }
                    } else if (train == trainB) {
                        if (train.getTiempoEspera() == 0) {
                            sendData("El tren DOS se encuentra en una estacion, saldra dentro de 10 minutos");
                        } else {
                            sendData("El tiempo aproximado para que el tren DOS llegue a la estacion de" + train.getDestino() + " es de " + train.getTiempoEspera() + " minutos");
                        }
                    }
                    break;
                case "cantidad":
                    if (train == trainA) {
                        sendData("El tren UNO esta transportando " + train.getPasajeros() + " pasajeros");
                    } else if (train == trainB) {
                        sendData("El tren DOS esta transportando " + train.getPasajeros() + " pasajeros");
                    }
                    break;
                case "dinero":
                    if (train == trainA) {
                        sendData("El tren UNO ha recolectado " + train.getMoneyA() + " colones");
                    } else if (train == trainB) {
                        sendData("El tren ha DOS ha recolectado " + train.getMoneyB() + " colones");
                    }
                    break;

                case "dinerototal":
                    sendData("Los trenes han recolectado " + train.getMoney() + " colones");
                    break;

                case "recorrido":
                    if (train == trainA) {
                        sendData("El tren UNO ha recorridio " + train.getRecorrido() + " estaciones");
                    } else if (train == trainB) {
                        sendData("El tren DOS ha recorridio " + train.getRecorrido() + " estaciones");
                    }
                    break;

                case "detener":                       
                        if (train == trainA) {
                        train.suspenderTrenA();
                        sendData("El tren UNO se detuvo correctamente.");
                        } else if (train == trainB) {
                         train.suspenderTrenB();
                        sendData("El tren DOS se detuvo correctamente.");
                        }
                    break;
                case "reanudar":
                        if (train == trainA) {
                        train.reanudarTrenA();
                        sendData("El tren UNO se reanudó correctamente.");
                        } else if (train == trainB) {
                         train.reanudarTrenB();
                        sendData("El tren DOS se reanudó correctamente.");
                        }
                        
                    break;
                default:
                    break;
            }
               readDataAdmin(train);
        } catch (IOException ex) {
            System.out.print("");
            //Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void sendData(String mensaje) { //Envía la información a los clientes
        try {
            out.writeUTF(mensaje);
            out.flush();
        } catch (IOException ex) {
            Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
