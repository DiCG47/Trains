/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Adrian Vinicio
 */
public class Admin {

    private Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;

    public Admin() {
        try {
            socket = new Socket(InetAddress.getLocalHost(), 7841);
            startStream();
        } catch (UnknownHostException ex) {
            Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void startStream() {
        try {
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());
        } catch (IOException ex) {
            Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public String readData() {
        //Lee los mensajes enviados por el servidor
        try {
            if (socket.getInetAddress() != null) {
                String info = in.readUTF();
                return info; //Retorna la respuesta del server
            }
        } catch (IOException ex) {
            Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "";
    }

    public void sendData(String peticion) {
        try {   
            out.writeUTF(peticion);
            out.flush();
        } catch (IOException ex) {
            Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void First(String tren) {
        try {
            out.writeUTF(tren + " admin"); //Envía el tren que desea ver y el un identificador para que el server sepa que fue enviado por el Admin
            out.flush();
        } catch (IOException ex) {
            Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
