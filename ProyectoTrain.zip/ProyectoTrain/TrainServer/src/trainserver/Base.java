/*
Trenes : Ruta establecida, Capacidad maxima, Sumatoria de costo de Tickets(Admin),
Duracion de recorrido (Admin),la hora en que llega a las estaciones(admin),
Detener el tren y reportar y renaudar cuando el admin lo desea
 */
package trainserver;

public abstract class Base {

    private int id;
    private String name;
    private int maxcapacity;
    private int routeid;
    private int money;

    public Base(int id, String name, int maxcapacity, int routeid, int money) {
        this.id = id;
        this.name = name;
        this.maxcapacity = maxcapacity;
        this.routeid = routeid;
        this.money = money;
    }

    public Base() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMaxcapacity() {
        return maxcapacity;
    }

    public void setMaxcapacity(int maxcapacity) {
        this.maxcapacity = maxcapacity;
    }

    public int getRouteid() {
        return routeid;
    }

    public void setRouteid(int routeid) {
        this.routeid = routeid;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

}
