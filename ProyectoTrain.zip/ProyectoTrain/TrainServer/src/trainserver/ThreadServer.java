/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainserver;

import Trains.TrainA;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Adrian Vinicio
 */
public class ThreadServer {
    
    private ServerSocket serverSocker;
    private Socket socket;
    private ExecutorService service;
   
    
    public ThreadServer() {
        try {      
            service = Executors.newCachedThreadPool();
            this.serverSocker = new ServerSocket(7841);
            waitClient();
        } catch (IOException ex) {
            Logger.getLogger(ThreadServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void waitClient() {
       
        try {           
            socket = serverSocker.accept();
            TrainA A = new TrainA(socket);
            service.submit(A); 
            
            while (true) {  
//                socket = serverSocker.accept(); 
                A.readData();
                        
            }
        } catch (IOException ex) {
            Logger.getLogger(ThreadServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
   
}
