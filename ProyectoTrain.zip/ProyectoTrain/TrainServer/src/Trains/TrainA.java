/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Trains;

import Routes.TrainRouteA;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import static java.lang.Thread.sleep;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Adrian Vinicio
 */
public class TrainA implements Runnable{


    
    private Socket socket;
    private ObjectInputStream in;
    private ObjectOutputStream out;
    TrainRouteA route = new TrainRouteA();
    private int pasajeros;
    private int pasajerosNuevos;
    private int pasajerosBajan;
    private int money;
    private int tiempoEspera = 0;
    private String estacion = "";
    private int recorrido = 0;
    
  
    
    public TrainA(final Socket socket) {                
            this.socket = socket;
            
            startStream();            
    }

    
    @Override
    public  void run() {
       
        pasajeros = (int) (Math.random() * (100-10+1) + 10);
        money = pasajeros * 500;
        
        estacion = route.PlacesA.get(0);
        System.out.println("El tren ha salido de la estacion con " + pasajeros + " pasajeros"); 
        System.out.println("El tren se dirige a la estacion de " + estacion);        
        System.out.println("Tiempo en llegar a la estacion x: 40 minutos");
        tiempoEspera = 40;
               
        for(int x = 0; x < 10; x++){
            try {              
                tiempoEspera = tiempoEspera - 4;                                   
                sleep(2000);             
            } catch (InterruptedException ex) {
                Logger.getLogger(TrainA.class.getName()).log(Level.SEVERE, null, ex);
            }
        }        
        estacion = route.PlacesA.get(1);
        recorrido++;
        System.out.println("El tren ha llegado a la estacion " +  route.PlacesA.get(1)  + " y va a salir en 10 minutos");
         
        for(int x = 0; x < 5; x++){
            try {    
                sleep(2000);             
            } catch (InterruptedException ex) {
                Logger.getLogger(TrainA.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        pasajerosBajan = (int) (Math.random() * (40-10+1) + 10);
        pasajerosNuevos = (int) (Math.random() * (50-10+1) + 10);     
        int acumulado = 0;
        pasajeros = (pasajeros + pasajerosNuevos) - pasajerosBajan;
        if(pasajeros > 150){
           while(pasajeros > 150){
               pasajeros--; 
               acumulado++;
           } 
        }
        money = money + ((pasajerosNuevos - acumulado) * 500);
               
        System.out.println("El tren ha salido de la estacion con " + pasajeros + " pasajeros");
        System.out.println("El tren se dirige a la estacion de " + estacion);        
        System.out.println("Tiempo en llegar a la estacion x: 50 minutos");
        
        tiempoEspera = 50;
        for(int x = 0; x < 10; x++){
            try {              
                tiempoEspera = tiempoEspera - 5;                                   
                sleep(2000);             
            } catch (InterruptedException ex) {
                Logger.getLogger(TrainA.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        estacion = route.PlacesA.get(2); 
        recorrido++;
        System.out.println("El tren ha llegado a la estacion " + route.PlacesA.get(1) + "y va a salir en 10 minutos");
        
        for(int x = 0; x < 5; x++){
            try {              
                sleep(2000);             
            } catch (InterruptedException ex) {
                Logger.getLogger(TrainA.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        pasajerosBajan = (int) (Math.random() * (40-10+1) + 10);
        pasajerosNuevos = (int) (Math.random() * (50-10+1) + 10);
               
        acumulado = 0;
        pasajeros = (pasajeros + pasajerosNuevos) - pasajerosBajan;
        if(pasajeros > 150){
           while(pasajeros > 150){
               pasajeros--; 
               acumulado++;
           } 
        }
        money = money + ((pasajerosNuevos - acumulado) * 500);
        
        
        System.out.println("El tren ha salido de la estacion con " + pasajeros + " pasajeros");
        System.out.println("El tren se dirige a la estacion de " + estacion );        
        System.out.println("Tiempo en llegar a la estacion x: 60 minutos");
        
        tiempoEspera = 60;
        for(int x = 0; x < 10; x++){
            try {              
                tiempoEspera = tiempoEspera - 6;                                   
                sleep(2000);             
            } catch (InterruptedException ex) {
                Logger.getLogger(TrainA.class.getName()).log(Level.SEVERE, null, ex);
            }
        }     
        estacion = route.PlacesA.get(2);
        recorrido++;
        System.out.println("El tren ha llegado a su ultima estacion " + estacion);               
        System.out.println("El tren ha llegado con " + pasajeros + " pasajeros a la ultima parada");
        System.out.println("El tren recolecto " + money + " colones");
    
    
    }
    
      
    public void startStream(){   
        try {
            in = new ObjectInputStream(socket.getInputStream());
            out = new ObjectOutputStream(socket.getOutputStream());    
        } catch (IOException ex) {
            Logger.getLogger(TrainA.class.getName()).log(Level.SEVERE, null, ex);
        }           
    }
    
    public void readData(){
        String mensaje;
        try {
            String Tren = in.readUTF();
            if(Tren.equals("1")){
            String usuario = in.readUTF();
            if(usuario.equals("client")){
                
                mensaje = in.readUTF();
                if(mensaje.equals("costo")){
                    sendData("El costo del pasaje es 500 colones");
                    
                }else if(mensaje.equals("tiempo")){
                        
                    if(tiempoEspera == 0){
                       sendData("El tren se encuentra en una estacion, saldra dentro de 10 minutos");  
                    }else{
                        String t = String.valueOf(tiempoEspera);           
                        sendData("El tiempo aproximado para que el tren llegue a la estacion es de " + t + " minutos");  
                    } 
                    
                }else if(mensaje.equals("servicio")){
//////////////////////////////////    
/////////////////////////////////
//////////////////////////////////
                }else if(mensaje.equals("destino")){
//                    String destino = "El destino del tren es la estacion " + estacion;
                    sendData("El destino del tren es la estacion " + estacion);
                }   
////////////////////////////////////////////////////////////                
            }else if(usuario.equals("admin")){
                
                mensaje = in.readUTF();
                if(mensaje.equals("capacidad")){
                    String p = String.valueOf(pasajeros); 
                    sendData("El tren esta transportando " + p + " pasajeros");
                    
                }else if(mensaje.equals("dinero")){
                        
                    String m = String.valueOf(money);           
//                    String ganancias = "El tren ha recolectado " + m + " colones";
                    sendData("El tren ha recolectado " + m + " colones"); 
                    
                }else if(mensaje.equals("detener")){
                                          
                }else if(mensaje.equals("reanudar")){
                    
                }else if(mensaje.equals("tiempo")){
                    if(tiempoEspera == 0){
                       sendData("El tren se encuentra en una estacion, saldra dentro de 10 minutos");  
                    }else{
                        String t = String.valueOf(tiempoEspera);           
                        sendData("El tiempo aproximado para que el tren llegue a la estacion es de " + t + " minutos");  
                    }
                   
                }else if(mensaje.equals("recorrido")){
                    String r = String.valueOf(recorrido);
                    sendData("El tren ha recorrdio " + r + " estaciones");
                }
                        
            }           
        }
        } catch (IOException ex) {
            Logger.getLogger(TrainA.class.getName()).log(Level.SEVERE, null, ex);
        }
          
    }
    
    
    
    
    public void sendData(String mensaje){

        try {   
            out.writeUTF(mensaje);    
            out.flush();   
        } catch (IOException ex) {
            Logger.getLogger(TrainA.class.getName()).log(Level.SEVERE, null, ex);
        }
       

    }
    
}
