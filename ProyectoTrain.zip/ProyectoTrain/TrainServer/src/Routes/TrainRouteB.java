
package Routes;

import java.util.ArrayList;
import trainserver.Base;


public class TrainRouteB extends Base{
    
    
    private final ArrayList<String> PlacesB = new ArrayList<String>();
    private int moneyB;

    public TrainRouteB(int moneyB, int id, String name, int maxcapacity, int routeid, int money) {
        super(id, name, maxcapacity, routeid, money);
        
        this.moneyB = moneyB;
    }

    public TrainRouteB(int moneyB) {
        
        this.moneyB = moneyB;
    }

    public int getMoneyB() {
        return moneyB;
    }

    public void setMoneyB(int moneyB) {
        this.moneyB = moneyB;
    }
    
    
        public TrainRouteB()
    {
    
    PlacesB.add("Heredia");
    PlacesB.add("La Isla");
    PlacesB.add("Coronado");   
           
    }
    
    
    
    
}
