
package Routes;

import java.util.ArrayList;
import trainserver.Base;

public class TrainRouteA extends Base {

    
    public ArrayList<String> PlacesA = new ArrayList<String>();
    private int moneyA;

    public TrainRouteA(int id, String name, int maxcapacity, int routeid, int money, int moneyA) {
        super(id, name, maxcapacity, routeid, money);        
        this.moneyA = moneyA;

    }

    public TrainRouteA( int moneyA) {       
        this.moneyA = moneyA;
    }

    public int getMoneyA() {
        return moneyA;
    }

    public void setMoneyA(int moneyA) {
        this.moneyA = moneyA;
    }  
        
    public TrainRouteA(){  
        PlacesA.add("San Jose");
        PlacesA.add("Guadalupe");
        PlacesA.add("San Pedro");             
    }
    
    
    
    
    
}
