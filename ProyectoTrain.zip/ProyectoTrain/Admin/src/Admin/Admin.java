/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Adrian Vinicio
 */
public class Admin {
    
     private Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;

    public Admin(){
        try {
            socket = new Socket(InetAddress.getLocalHost(),7841);
            startStream();
        } catch (UnknownHostException ex) {
            Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void startStream(){
        try {
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());
        } catch (IOException ex) {
            Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void readData(){

        try {
            if(socket.getInetAddress() != null){          
                String info = in.readUTF();
                System.out.println(info);                                                    
            }
        }catch (IOException ex) {
                Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void sendData(){        
        try {           
            int opcion = Integer.parseInt(JOptionPane.showInputDialog("1.Capacidad\n2.Dinero\n3.Detener\n4.Reanudar\n5.Tiempo de llegada\n6.Recorrido"));
            
            if(opcion == 1){
                out.writeUTF("capacidad");     
                out.flush();  
            }else if(opcion == 2){
                out.writeUTF("dinero");     
                out.flush();  
            }else if(opcion == 3){
               out.writeUTF("detener");     
                out.flush();  
            }else if(opcion == 4){
                out.writeUTF("reanudar");     
                out.flush();  
            }else if(opcion == 5){
                out.writeUTF("tiempo");     
                out.flush();  
            }else if(opcion == 6){
                out.writeUTF("recorrido");     
                out.flush();  
            }
                          
        } catch (IOException ex) {
            Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public void First(String tren){       
        try {
            out.writeUTF(tren);
            out.flush();
                       
            String mensaje = "admin";
            out.writeUTF(mensaje);     
            out.flush();
                   
        } catch (IOException ex) {
            Logger.getLogger(Admin.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
