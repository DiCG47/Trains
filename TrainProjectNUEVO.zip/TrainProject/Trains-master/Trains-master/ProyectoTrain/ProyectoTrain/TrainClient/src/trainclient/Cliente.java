/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainclient;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

/**
 *
 * @author Adrian Vinicio
 */
public class Cliente {

    private Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;

    public Cliente() {
        try {
            socket = new Socket(InetAddress.getLocalHost(), 7841);
            startStream();
        } catch (UnknownHostException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void startStream() {
        try {
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void readData() {

        try {
            String info = in.readUTF();
            System.out.println(info);
            sendData();
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void sendData() {
        try {
            int opcion = Integer.parseInt(JOptionPane.showInputDialog("1. Costo\n2. Tiempo de espera\n3. Destino"));
            String peticion = "";
            if (opcion == 1) {
                peticion = "costo";
            } else if (opcion == 2) {
                peticion = "tiempo";
            } else if (opcion == 3) {
                peticion = "destino";
            }
            
            out.writeUTF(peticion);
            out.flush();
            readData();
            
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void First(String tren) {
        try {
            out.writeUTF(tren); //Envía el tren que desea ver
            out.flush();

            String mensaje = "client";
            out.writeUTF(mensaje);//Envía un mensaje para que el server lo identifique como cliente. 
            out.flush();

            sendData();

        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
