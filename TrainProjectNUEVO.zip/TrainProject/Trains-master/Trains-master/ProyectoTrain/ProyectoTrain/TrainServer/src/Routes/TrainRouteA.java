
package Routes;

import java.util.ArrayList;
import TrainServerTCP.Base;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TrainRouteA extends Base {

    
    private ArrayList<String> PlacesA = new ArrayList<String>();
    private int moneyA;
    private int moneyB;
    private static boolean a = true;
    
    public TrainRouteA(int id, String name, int maxcapacity, int routeid, int money, int moneyA) {
        super(id, name, maxcapacity, routeid, money);        
        this.moneyA = moneyA;

    }
    
    public TrainRouteA(){  
        PlacesA.add("San Jose");
        PlacesA.add("Guadalupe");
        PlacesA.add("San Pedro");   
        PlacesA.add("Heredia");
        PlacesA.add("La Isla");
        PlacesA.add("Coronado");   
    }

    public TrainRouteA( int moneyA) {       
        this.moneyA = moneyA;
    }

    public int getMoneyA() {
        return moneyA;
    }

    public void setMoneyA(int moneyA) {
        this.moneyA = moneyA;
    }  

    public int getMoneyB() {
        return moneyB;
    }

    public void setMoneyB(int moneyB) {
        this.moneyB = moneyB;
    }

    public synchronized String getPlacesA1(int x) {
        
        while(a == false){
            try {
                System.out.println(1);
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(TrainRouteA.class.getName()).log(Level.SEVERE, null, ex);
            }
        }       
        
        a = false;
        notify();
        return PlacesA.get(x);
    }
    
    public synchronized String getPlaceA2(int x){
        
        while(a == true){
            try {
               System.out.println(2); 
       
               wait();
                
            } catch (InterruptedException ex) {
                Logger.getLogger(TrainRouteA.class.getName()).log(Level.SEVERE, null, ex);
            }
        }       
        
        a = true;
        notify();
        return PlacesA.get(x);
    }

    public ArrayList<String> SizePlacesA() {
        return PlacesA;
    }
    
    public void setPlacesA(ArrayList<String> PlacesA) {
        this.PlacesA = PlacesA;
    }
      
    

}
