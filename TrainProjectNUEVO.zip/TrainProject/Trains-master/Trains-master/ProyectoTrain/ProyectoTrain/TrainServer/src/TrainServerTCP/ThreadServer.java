/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TrainServerTCP;

import ThreadsTrains.TrainBase;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Adrian Vinicio
 */
public class ThreadServer {

    private ServerSocket serverSocker;
    private Socket socket;
    private ExecutorService service;
    TrainBase trainA, trainB;
    
    public ThreadServer(TrainBase trainA, TrainBase trainB) {
        this.trainA = trainA;
        this.trainB = trainB;
        
        try {
            service = Executors.newCachedThreadPool();
            this.serverSocker = new ServerSocket(7841);
            waitClient();
        } catch (IOException ex) {
            Logger.getLogger(ThreadServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void waitClient() {
        try {
            while (true) {
                socket = serverSocker.accept();
                ServerClient A = new ServerClient(socket, trainA, trainB);
                service.submit(A);
            }
        } catch (IOException ex) {
            Logger.getLogger(ThreadServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
