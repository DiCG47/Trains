
package ThreadsTrains;

import static java.lang.Thread.sleep;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TrainBase{
    
    private int pasajeros;
    private int pasajerosNuevos;
    private int pasajerosBajan;
    private int money = 0;          ////////////////////////////////////////////////////////////////////////////////
    private int tiempoEspera;
    private String estacionActual;
    private String destino;
    private int recorrido;
    private int acumulado;
    private boolean suspender;
    private boolean pausar;
    public ArrayList<String> PlacesA = new ArrayList<String>();
    private int moneyA;
    private int moneyB;
    private static boolean estado = true;

    public TrainBase() {
        this.tiempoEspera = 0;  
        this.estacionActual = "";
        this.acumulado = 0;
        this.recorrido = 0;
        this.suspender = true;
        this.pausar = false;
        this.moneyA = moneyA;

    }

    public TrainBase( int moneyA) {       
        this.moneyA = moneyA;
    }

    public int getMoneyA() { ////////////////////////////////////////////////////////////
        return moneyA;
    }

    public void setMoneyA(int moneyA) {
        this.moneyA = moneyA;
    }  

    public int getMoneyB() {   ////////////////////////////////////////////////////////////
        return moneyB;
    }

    public void setMoneyB(int moneyB) {
        this.moneyB = moneyB;
    }
    

    public int getPasajeros() {
        return pasajeros;
    }

    public void setPasajeros(int pasajeros) {
        this.pasajeros = pasajeros;
    }

    public int getPasajerosNuevos() {
        return pasajerosNuevos;
    }

    public void setPasajerosNuevos(int pasajerosNuevos) {
        this.pasajerosNuevos = pasajerosNuevos;
    }

    public int getPasajerosBajan() {
        return pasajerosBajan;
    }

    public void setPasajerosBajan(int pasajerosBajan) {
        this.pasajerosBajan = pasajerosBajan;
    }

    public int getMoney() {
        return money;
    }

    public synchronized void setMoney1(int dinero) { //////////////////////////////////////////////////////////
                  
        while(estado == false){
            try {
                System.out.println(3);
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(TrainBase.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        money = money + dinero;
        estado = false;      
        notify();
        
    }
    
    public synchronized void setMoney2(int dinero){
        while(estado == true){
            try {
                System.out.println(4);
                wait();

                System.out.println(1);
            } catch (InterruptedException ex) {
                Logger.getLogger(TrainBase.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        money = money + dinero;
        estado = true;
        
        notify();
    }

    public int getTiempoEspera() {
        return tiempoEspera;
    }

    public void setTiempoEspera(int tiempoEspera) {
        this.tiempoEspera = tiempoEspera;
    }

    public String getEstacionActual() {
        return estacionActual;
    }

    public void setEstacionActual(String estacion) {
        this.estacionActual = estacion;
    }

    public int getRecorrido() {
        return recorrido;
    }

    public void setRecorrido(int recorrido) {
        this.recorrido = recorrido;
    }

    public int getAcumulado() {
        return acumulado;
    }

    public void setAcumulado(int acumulado) {
        this.acumulado = acumulado;
    }

    public boolean getSuspender() {
        return suspender;
    }

    public void setSuspender(boolean suspender) {
        this.suspender = suspender;
    }

    public boolean isPausar() {
        return pausar;
    }

    public void setPausar(boolean pausar) {
        this.pausar = pausar;
    }

    public ArrayList<String> getPlacesA() {
        return PlacesA;
    }

    public void setPlacesA(ArrayList<String> PlacesA) {
        this.PlacesA = PlacesA;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }
    
    public void suspenderTren() {

    }
    
    public void reanudarTren() {

    }
}
