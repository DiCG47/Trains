/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ThreadsTrains;

import TrainServerTCP.ServerClient;
import Routes.TrainRouteA;
import static java.lang.Thread.sleep;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author sramirez
 */
public class ThreadTrainA extends Thread {

    public TrainRouteA route;
    public ClassTrainA train;
    private String estacion; 
    private String dinero;

    public ThreadTrainA() {
        this.route = new TrainRouteA();
        this.train = new ClassTrainA(); 
    }

    @Override
    public void run() {

        train.setPasajeros((int) (Math.random() * (100 - 10 + 1) + 10));
        train.setMoneyA(train.getPasajeros() * 500);
        train.setMoney1(train.getMoneyA());
        
        for (int i = 0; i < route.SizePlacesA().size()- 1; i++) {
          
            train.setRecorrido(train.getRecorrido() + 1);
            
            System.out.println("El tren UNO está en la estación de " + route.getPlacesA1(i) + " con " + train.getPasajeros() + " pasajeros.");       
            train.setDestino(route.getPlacesA1(i + 1));
            System.out.println("El tren UNO se dirige a la estacion de " + train.getDestino());
            train.setTiempoEspera(40);
            System.out.println("Tiempo en llegar del tren UNO a " + train.getDestino() + ": " + train.getTiempoEspera() + " minutos");

            for (int x = 0; x < 10; x++) {
                try {
                    train.setTiempoEspera(train.getTiempoEspera() - 4);
                    sleep(2000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            train.setTiempoEspera(10);
            
            System.out.println("El tren UNO ha llegado a la estacion " + train.getDestino() + " y va a salir en " + train.getTiempoEspera() + " minutos");

            for (int x = 0; x < 5; x++) {
                try {
                    sleep(2000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            train.setPasajerosBajan((int) (Math.random() * (40 - 10 + 1) + 10));
            train.setPasajerosNuevos((int) (Math.random() * (50 - 10 + 1) + 10));

            train.setPasajeros((train.getPasajeros() + train.getPasajerosNuevos()) - train.getPasajerosBajan());

            if (train.getPasajeros() > 150) {
                while (train.getPasajeros() > 150) {
                    train.setPasajeros(train.getPasajeros() - 1);
                    train.setAcumulado(train.getAcumulado() + 1);
                }
            }
            train.setMoneyA(train.getMoneyA() + (train.getPasajerosNuevos() - train.getAcumulado()) * 500);
            
            train.setMoney1(train.getMoneyA());          
            
        } //Fin del FOR

    }

    public void suspenderTren() {
        train.setSuspender(true);
        while (train.getSuspender()) {
            try {          
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(ThreadTrainA.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void reanudarTren() {
        train.setSuspender(false);
        notify();
    }
}
