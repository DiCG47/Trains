/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ThreadsTrains;

/**
 *
 * @author sramirez
 */
public class ClassTrainA extends TrainBase{ //Hereda todo de la clase TrainBase
    
}
