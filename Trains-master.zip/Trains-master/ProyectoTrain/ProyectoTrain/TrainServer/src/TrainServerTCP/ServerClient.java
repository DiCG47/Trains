/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TrainServerTCP;

import ThreadsTrains.ThreadTrainA;
import ThreadsTrains.ThreadTrainB;
import ThreadsTrains.TrainBase;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Adrian Vinicio
 */
public class ServerClient implements Runnable {

    private Socket socket;
    private ObjectInputStream in;
    private ObjectOutputStream out;
    
    TrainBase trainA, trainB;
       
    public ServerClient(final Socket socket, TrainBase trainA, TrainBase trainB) {
        this.trainA = trainA;
        this.trainB = trainB;
        
        this.socket = socket;
        startStream();
    }

    @Override
    public void run() {
        firstReadData();
    }

    public void startStream() {
        try {
            in = new ObjectInputStream(socket.getInputStream());
            out = new ObjectOutputStream(socket.getOutputStream());
        } catch (IOException ex) {
            Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void firstReadData() {
        try {
            String Tren = in.readUTF();
            if (Tren.equals("1")) { // ------- TRAIN A
                String usuario = in.readUTF();
                if (usuario.equals("client")) {
                    readDataClient(trainA);
                } else if (usuario.equals("admin")) {
                    readDataAdmin(trainA);
                }
            } else if (Tren.equals("2")) { //------ TRAIN B
                String usuario = in.readUTF();
                if (usuario.equals("client")) {
                    readDataClient(trainB);
                } else if (usuario.equals("admin")) {
                    readDataAdmin(trainB);
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void readDataClient(TrainBase train) {
        try {
            String mensaje = in.readUTF();
            switch (mensaje) {
                case "costo":
                    sendData("El costo del pasaje es 500 colones.");
                    break;
                case "tiempo":
                    if (train.getTiempoEspera() == 0) {
                        sendData("El tren se encuentra en una estacion, saldra dentro de 10 minutos.");
                    } else {
                        sendData("El tiempo aproximado para que el tren llegue a la estacion es de " + train.getTiempoEspera() + " minutos");
                    }   break;
                case "servicio":
                    break;
                case "destino":
                    sendData("El destino del tren es la estacion " + train.getDestino());
                    break;
                default:
                    break;
            }
            readDataClient(train);
        } catch (IOException ex) {
            Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void readDataAdmin(TrainBase train) {
        try {
            
            String mensaje = in.readUTF();
            switch (mensaje) {
                case "capacidad":
                    if(train == trainA){
                        sendData("El tren UNO esta transportando " + train.getPasajeros() + " pasajeros");
                    }else if(train == trainB){
                        sendData("El tren DOS esta transportando " + train.getPasajeros() + " pasajeros");
                    } 
                    break;
                case "dinero":
                    if(train == trainA){
                        sendData("El tren UNO ha recolectado " + train.getMoneyA() + " colones");
                    }else if(train == trainB){
                        sendData("El tren ha DOS ha recolectado " + train.getMoneyB() + " colones");
                    } 
                    break;
                    
                case "dineroTotal":
                      sendData("Los trenes han recolectado " + train.getMoney() + " colones");
                    break;
                case "detener":
                    
                    break;
                case "reanudar":
                    
                    break;
                case "tiempo":
                    
                    if(train == trainA){
                        if (train.getTiempoEspera() == 0) {
                        sendData("El tren UNO se encuentra en una estacion, saldra dentro de 10 minutos");
                        } else {
                        sendData("El tiempo aproximado para que el tren UNO llegue a la estacion es de " + train.getTiempoEspera() + " minutos");
                        }                       
                    }else if(train == trainB){
                        if (train.getTiempoEspera() == 0) {
                        sendData("El tren DOS se encuentra en una estacion, saldra dentro de 10 minutos");
                        } else {
                        sendData("El tiempo aproximado para que el tren DOS llegue a la estacion es de " + train.getTiempoEspera() + " minutos");
                        }
                    }
                    
                    break;
                case "recorrido":                  
                    if(train == trainA){
                        sendData("El tren UNO ha recorridio " + train.getRecorrido() + " estaciones");
                    }else if(train == trainB){
                       sendData("El tren DOS ha recorridio " + train.getRecorrido() + " estaciones");
                    } 
                    break;
                default:
                    break;
            }
            readDataAdmin(train);
        } catch (IOException ex) {
            Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void sendData(String mensaje) {
        try {
            out.writeUTF(mensaje);
            out.flush();
        } catch (IOException ex) {
            Logger.getLogger(ServerClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
