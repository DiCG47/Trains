
package Routes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
// Como accesar a la ruta?
//  ArrayList<String> values = TrainRouteAenum.getPlacesA();

public enum TrainRouteAenum { 

   

    PARADA1A("San Jose"),
    PARADA2A("Guadalupe"),
    PARADA3A("San Pedro"),
    PARADA4A("Sabanilla"),
    PARADA5A("El Carmen"),
    PARADA6A("Coronado");


    
    private static final ArrayList<String> PLACESA = new ArrayList<String>();
    private final String placea;
    private static boolean a = true;

    static {
        
        for (TrainRouteAenum trainrouteaenum : TrainRouteAenum.values()) {
            PLACESA.add(trainrouteaenum.placea);
        }
    }

    private TrainRouteAenum(String placea) {
        this.placea = placea;
    }

    public static List<String> getPlacesA() {
        return Collections.unmodifiableList(PLACESA);
    }
    
    public synchronized String getPlacesA1(int x) {
        
        while(a == false){
            try {
                System.out.println(1);
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(TrainRouteA.class.getName()).log(Level.SEVERE, null, ex);
            }
        }       
        
        a = false;
        notify();
        return PLACESA.get(x);
    }
    
    public synchronized String getPlaceA2(int x){
        
        while(a == true){
            try {
               System.out.println(2); 
       
               wait();
                
            } catch (InterruptedException ex) {
                Logger.getLogger(TrainRouteA.class.getName()).log(Level.SEVERE, null, ex);
            }
        }       
        
        a = true;
        notify();
        return PLACESA.get(x);
    }

    public ArrayList<String> SizePlacesA() {
        return PLACESA;
    }
    
    
    /// No es posible hacer sets btw//
    
    // De igual forma busque si se utiliza este metodo y no se utiliza.
    
//    public void setPlacesA(ArrayList<String> PlacesA) {
//        this.PLACESA = PLACESA;
//    }
    
    
    

}
    

    
    
    

