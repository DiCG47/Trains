
package Routes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
// Como accesar a la ruta?
//  ArrayList<String> values = TrainRouteBenum.getPlacesB();
// Los enums de la ruta A y B son espejos
// Decidi tener la misma cantidad de paradas por cualquier cosa
/**
 *
 * @author DiCG47 PC
 */
public enum TrainRouteBenum {
    
    PARADA1B("Cartago"),
    PARADA2B("Tres Rios"),
    PARADA3B("Momentum"),
    PARADA4B("La Galera"),
    PARADA5B("Curridabat"),
    PARADA6B("Zapote");
    
    private static final ArrayList<String> PLACESB = new ArrayList<String>();
    private final String placeb;
    private static boolean b = true;
    
    
    static {
        
        for (TrainRouteBenum trainroutebenum : TrainRouteBenum.values()) {
            PLACESB.add(trainroutebenum.placeb);
        }
    }

    private TrainRouteBenum(String placeb) {
        this.placeb = placeb;
    }

    public static List<String> getPlacesB() {
        return Collections.unmodifiableList(PLACESB);
    }
    
    public synchronized String getPlacesB1(int x) {
        
        while(b == false){
            try {
                System.out.println(1);
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(TrainRouteA.class.getName()).log(Level.SEVERE, null, ex);
            }
        }       
        
        b = false;
        notify();
        return PLACESB.get(x);
    }
    
    public synchronized String getPlaceB2(int x){
        
        while(b == true){
            try {
               System.out.println(2); 
       
               wait();
                
            } catch (InterruptedException ex) {
                Logger.getLogger(TrainRouteA.class.getName()).log(Level.SEVERE, null, ex);
            }
        }       
        
        b = true;
        notify();
        return PLACESB.get(x);
    }

    public ArrayList<String> SizePlacesB() {
        return PLACESB;
    }
    
    
    /// No es posible hacer sets btw//
    
    // De igual forma busque si se utiliza este metodo y no se utiliza.
    
//    public void setPlacesA(ArrayList<String> PlacesA) {
//        this.PLACESA = PLACESA;
//    }
    
}
