/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainclient;

import javax.swing.JOptionPane;

/**
 *
 * @author Adrian Vinicio
 */
public class Main {
    
    public static void main(String args[]){
         Cliente cliente = new Cliente();
         
         int salir = 1;
         while(salir != 0){             
            String tren = JOptionPane.showInputDialog("Cuál tren desea ver: 1.Tren A"); 
            cliente.First(tren);
//            cliente.sendData();
//            cliente.readData();
            //salir = Integer.parseInt(JOptionPane.showInputDialog("0. Salir"));
        }
    }
}
